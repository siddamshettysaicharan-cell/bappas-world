import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { PlayerProfile, LeaderboardEntry } from '../types';

// Retrieve environment variables via Vite's import.meta.env
const supabaseUrl = (import.meta.env.VITE_SUPABASE_URL as string | undefined)?.trim();
const supabaseKey = (
  (import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string | undefined) ||
  (import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined)
)?.trim();

let _supabaseClient: SupabaseClient | null = null;

/**
 * Lazily initialize and return the Supabase client
 */
export function getSupabaseClient(): SupabaseClient | null {
  if (_supabaseClient) {
    return _supabaseClient;
  }

  if (!supabaseUrl || !supabaseKey) {
    return null;
  }

  try {
    _supabaseClient = createClient(supabaseUrl, supabaseKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    });
    return _supabaseClient;
  } catch (error) {
    console.warn('[Supabase] Failed to initialize Supabase client:', error);
    return null;
  }
}

/**
 * Normalizes college name for cross-player matching:
 * - lowercase
 * - trim whitespace
 * - collapse repeated spaces
 * - normalize apostrophes and punctuation
 */
export function normalizeCollege(college: string): string {
  if (!college) return '';
  return college
    .toLowerCase()
    // Replace smart quotes and apostrophes (e.g., 'St. Mary's' vs 'St Marys')
    .replace(/[\u2018\u2019\u201A\u201B\u2032\u2035']/g, '')
    // Replace punctuation with spaces
    .replace(/[^\w\s]/g, ' ')
    // Collapse repeated whitespace
    .replace(/\s+/g, ' ')
    .trim();
}

const PLAYER_STORAGE_KEY = 'ganesha_player_profile';
const PLAYER_ID_STORAGE_KEY = 'ganesha_player_id';

/**
 * Retrieves the saved local player profile from localStorage if present
 */
export function getLocalPlayerProfile(): PlayerProfile | null {
  try {
    const raw = localStorage.getItem(PLAYER_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && (parsed.id || parsed.name)) {
        return parsed as PlayerProfile;
      }
    }
  } catch (e) {
    console.warn('[Storage] Error reading player profile:', e);
  }
  return null;
}

/**
 * Saves player profile to localStorage
 */
export function saveLocalPlayerProfile(profile: PlayerProfile): void {
  try {
    localStorage.setItem(PLAYER_STORAGE_KEY, JSON.stringify(profile));
    localStorage.setItem(PLAYER_ID_STORAGE_KEY, String(profile.id));
  } catch (e) {
    console.warn('[Storage] Error saving player profile:', e);
  }
}

/**
 * Register a new player in Supabase 'players' table and save to localStorage
 */
export async function registerPlayer(name: string, college: string): Promise<PlayerProfile> {
  const trimmedName = name.trim();
  const trimmedCollege = college.trim();
  const normCollege = normalizeCollege(trimmedCollege);

  const client = getSupabaseClient();
  const payload = {
    name: trimmedName,
    college: trimmedCollege,
    college_normalized: normCollege,
  };

  if (!client) {
    console.info('[Supabase] Client not configured. Using local player ID.');
    const fallbackProfile: PlayerProfile = {
      id: 'player_' + Date.now(),
      ...payload,
    };
    saveLocalPlayerProfile(fallbackProfile);
    return fallbackProfile;
  }

  try {
    const { data, error } = await client
      .from('players')
      .insert([payload])
      .select()
      .single();

    if (error || !data) {
      console.warn('[Supabase] Insert player warning:', error?.message);
      const fallbackProfile: PlayerProfile = {
        id: 'player_' + Date.now(),
        ...payload,
      };
      saveLocalPlayerProfile(fallbackProfile);
      return fallbackProfile;
    }

    const savedProfile: PlayerProfile = {
      id: data.id,
      name: data.name || trimmedName,
      college: data.college || trimmedCollege,
      college_normalized: data.college_normalized || normCollege,
      created_at: data.created_at,
    };

    saveLocalPlayerProfile(savedProfile);
    return savedProfile;
  } catch (err) {
    console.error('[Supabase] Register player exception:', err);
    const fallbackProfile: PlayerProfile = {
      id: 'player_' + Date.now(),
      ...payload,
    };
    saveLocalPlayerProfile(fallbackProfile);
    return fallbackProfile;
  }
}

/**
 * Saves a score record to the Supabase 'scores' table
 */
export async function saveGameScore(scoreData: {
  playerId: string | number;
  gameId: string;
  score: number;
}): Promise<boolean> {
  const client = getSupabaseClient();
  if (!client) {
    console.info('[Supabase] Client not active, skipping online score save.');
    return false;
  }

  if (scoreData.score < 0) return false;

  try {
    const payload = {
      player_id: scoreData.playerId,
      game_id: scoreData.gameId,
      score: Math.round(scoreData.score),
    };

    const { error } = await client.from('scores').insert([payload]);
    if (error) {
      console.warn('[Supabase] Error saving score:', error.message);
      return false;
    }

    console.log('[Supabase] Score saved successfully to scores table:', payload);
    return true;
  } catch (err) {
    console.error('[Supabase] Exception in saveGameScore:', err);
    return false;
  }
}

/**
 * Fetches the leaderboard for a specific game_id from Supabase
 */
export async function fetchGameLeaderboard(gameId: string): Promise<LeaderboardEntry[]> {
  const client = getSupabaseClient();
  if (!client) return [];

  try {
    // Attempt 1: Fetch scores with joined players table
    const { data: joinData, error: joinError } = await client
      .from('scores')
      .select('id, player_id, game_id, score, created_at, players ( id, name, college, college_normalized )')
      .eq('game_id', gameId)
      .order('score', { ascending: false })
      .limit(100);

    if (!joinError && joinData && joinData.length > 0) {
      return joinData.map((row, index) => {
        // Handle joined player object
        const p = Array.isArray(row.players) ? row.players[0] : row.players;
        const pName = p?.name || 'Devotee';
        const pCollege = p?.college || 'Campus';
        const pCollegeNorm = p?.college_normalized || normalizeCollege(pCollege);

        return {
          id: row.id,
          playerId: row.player_id,
          playerName: pName,
          college: pCollege,
          collegeNormalized: pCollegeNorm,
          gameId: row.game_id,
          score: row.score,
          createdAt: row.created_at,
          rank: index + 1,
        };
      });
    }

    // Attempt 2: Standalone queries if relation embedding isn't mapped
    const { data: rawScores, error: scoresError } = await client
      .from('scores')
      .select('id, player_id, game_id, score, created_at')
      .eq('game_id', gameId)
      .order('score', { ascending: false })
      .limit(100);

    if (scoresError || !rawScores || rawScores.length === 0) {
      return [];
    }

    const playerIds = Array.from(
      new Set(rawScores.map((s) => s.player_id).filter((id): id is string | number => id != null))
    );

    let playersMap = new Map<string, { name?: string; college?: string; college_normalized?: string }>();

    if (playerIds.length > 0) {
      const { data: playersList } = await client
        .from('players')
        .select('id, name, college, college_normalized')
        .in('id', playerIds);

      if (playersList) {
        playersMap = new Map(
          playersList.map((p) => [String(p.id), {
            name: p.name,
            college: p.college,
            college_normalized: p.college_normalized,
          }])
        );
      }
    }

    return rawScores.map((row, index) => {
      const p = playersMap.get(String(row.player_id));
      const pName = p?.name || 'Devotee';
      const pCollege = p?.college || 'Campus';
      const pCollegeNorm = p?.college_normalized || normalizeCollege(pCollege);

      return {
        id: row.id,
        playerId: row.player_id,
        playerName: pName,
        college: pCollege,
        collegeNormalized: pCollegeNorm,
        gameId: row.game_id,
        score: row.score,
        createdAt: row.created_at,
        rank: index + 1,
      };
    });
  } catch (err) {
    console.error('[Supabase] Exception in fetchGameLeaderboard:', err);
    return [];
  }
}

/**
 * Health / connection verification
 */
export async function verifySupabaseConnection(): Promise<boolean> {
  const client = getSupabaseClient();
  if (!client) return false;

  try {
    const { error } = await client.from('players').select('id', { count: 'exact', head: true });
    return !error;
  } catch {
    return false;
  }
}
